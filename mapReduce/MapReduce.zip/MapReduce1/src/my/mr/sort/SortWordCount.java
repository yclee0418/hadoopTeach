package my.mr.sort;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class SortWordCount {

	public static class KVBean implements WritableComparable<KVBean> {
		private String myWord;
		private long myCount;

		public String getMyWord() {
			return myWord;
		}

		public void setMyWord(String myWord) {
			this.myWord = myWord;
		}

		public long getMyCount() {
			return myCount;
		}

		public void setMyCount(long myCount) {
			this.myCount = myCount;
		}

		public KVBean() {
		}

		public KVBean(String myWord, long myCount) {
			super();
			this.myWord = myWord;
			this.myCount = myCount;
		}

		@Override
		public void readFields(DataInput in) throws IOException {
			myWord = in.readUTF().trim();
			myCount = in.readLong();
		}

		@Override
		public void write(DataOutput out) throws IOException {
			out.writeUTF(myWord);
			out.writeLong(myCount);

		}

		@Override
		public int compareTo(KVBean o) {
			if (myCount == o.getMyCount())
				return 0;
			return myCount > o.getMyCount() ? -1 : 1;
		}

		@Override
		public String toString() {
			return myWord + "->" + myCount;
		}
		
		

	}

	public static class SortMapper extends Mapper<Object, Text, KVBean, NullWritable> {

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			String line = value.toString();
			String[] fields = StringUtils.split(line, "\t");
			String word = fields[0].trim();
			Long count = Long.parseLong(fields[1].trim());

			context.write(new KVBean(word, count), NullWritable.get());
		}
	}

	public static class SortReducer extends Reducer<KVBean, NullWritable, Text, LongWritable> {

		public void reduce(KVBean key, Iterable<NullWritable> values, Context context)
				throws IOException, InterruptedException {
			context.write(new Text(key.getMyWord()), new LongWritable(key.getMyCount()));
		}
	}
	
	public static void main(String[] args) throws Exception {
	    Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Sort Word Count");
	    job.setJarByClass(SortWordCount.class);
	    job.setMapperClass(SortMapper.class);
	    //shuffle => re-combine the output part 1/2/3 of different mapper
	    //job.setCombinerClass(SortReducer.class);
	    job.setReducerClass(SortReducer.class);
	    //job.setPartitionerClass(HashPartition.class);
	    //job.setNumReduceTasks(2); ==> num of Reduce task cannot be less than partitions if more than 1
	    job.setMapOutputKeyClass(KVBean.class);
	    job.setMapOutputValueClass(NullWritable.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(LongWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
