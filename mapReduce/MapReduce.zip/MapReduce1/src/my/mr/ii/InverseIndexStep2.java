package my.mr.ii;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class InverseIndexStep2 {

	public static class StepTwoMapper extends Mapper<LongWritable, Text, Text, Text> {
		//private final static LongWritable one = new LongWritable(1);
		//private Text word = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			//value = all-->InverseWc2.txt	1
			String line = value.toString();
			String[] fields = StringUtils.split(line, "\t");
			String[] wordAndFileName = StringUtils.split(fields[0], "-->");
			context.write(new Text(wordAndFileName[0]), new Text(wordAndFileName[1] + "-->" + fields[1]));
		}
	}

	public static class StepTwoReducer extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			//values --> {a.txt-->1, b.txt-->2}
			List<String> strList = new ArrayList<String>();
			for (Text val : values) {
				strList.add(val.toString());
			}
			context.write(key, new Text(StringUtils.join(strList, ",")));
		}
	}
	
	public static void main(String[] args) throws Exception {
	    Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Inverse Word Count Step2");
	    job.setJarByClass(InverseIndexStep2.class);
	    job.setMapperClass(StepTwoMapper.class);
	    job.setReducerClass(StepTwoReducer.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(Text.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    
	    Path out = new Path(args[1]);
//	    FileSystem fs = FileSystem.get(conf);
//	    if (fs.exists(out)) {
//	    	fs.delete(out, true);
//	    }
	    FileOutputFormat.setOutputPath(job, out);
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
