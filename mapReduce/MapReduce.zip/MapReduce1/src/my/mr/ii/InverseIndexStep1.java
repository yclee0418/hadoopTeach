package my.mr.ii;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class InverseIndexStep1 {

	public static class StepOneMapper extends Mapper<LongWritable, Text, Text, LongWritable> {
		//private final static LongWritable one = new LongWritable(1);
		//private Text word = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			StringTokenizer itr = new StringTokenizer(value.toString());
			FileSplit split = (FileSplit) context.getInputSplit();
			String fileName = split.getPath().getName();
			while (itr.hasMoreTokens()) {
				String str = itr.nextToken().trim().toLowerCase();
				if (!StringUtils.isNotEmpty(str))
					continue;
				context.write(new Text(str + "-->" + fileName), new LongWritable(1));
			}
		}
	}

	public static class StepOneReducer extends Reducer<Text, LongWritable, Text, LongWritable> {
		public void reduce(Text key, Iterable<LongWritable> values, Context context)
				throws IOException, InterruptedException {
			long sum = 0;
			for (LongWritable val : values) {
				sum += val.get();
			}
			context.write(key, new LongWritable(sum));
		}
	}
	
	public static void main(String[] args) throws Exception {
	    Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "Inverse Word Count Step1");
	    job.setJarByClass(InverseIndexStep1.class);
	    job.setMapperClass(StepOneMapper.class);
	    job.setReducerClass(StepOneReducer.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(LongWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    
	    Path out = new Path(args[1]);
	    FileSystem fs = FileSystem.get(conf);
	    if (fs.exists(out)) {
	    	fs.delete(out, true);
	    }
	    FileOutputFormat.setOutputPath(job, out);
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	  }
}
